#!/bin/sh

set -e

python /app/pacscloudgateway_auth/manage.py makemigrations

python /app/pacscloudgateway_auth/manage.py migrate
uwsgi --ini /app/uwsgi/uwsgi.ini

