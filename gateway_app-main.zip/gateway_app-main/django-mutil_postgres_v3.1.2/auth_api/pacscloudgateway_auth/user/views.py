from django.contrib.auth.hashers import make_password
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import  generics, viewsets, views
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny




class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        permission_admin_actions = ['create']
        for admin_action in permission_admin_actions:
            if self.action == admin_action :
                permission_classes = [IsAdminUser]
            else:
                permission_classes = [IsAuthenticated,]
        return [permission() for permission in permission_classes]

    def get_queryset(self):
        if self.request.user and self.request.user.is_staff:
            owner_queryset = self.queryset.all().order_by('-date_joined')
        # after get all products on DB it will be filtered by its owner and return the queryset
        else:
            owner_queryset = self.queryset.filter(id=self.request.user.id)
        return owner_queryset


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
