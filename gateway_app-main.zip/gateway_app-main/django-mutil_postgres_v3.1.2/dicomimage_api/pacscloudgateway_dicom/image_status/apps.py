from django.apps import AppConfig


class ImageStatusConfig(AppConfig):
    name = 'image_status'
