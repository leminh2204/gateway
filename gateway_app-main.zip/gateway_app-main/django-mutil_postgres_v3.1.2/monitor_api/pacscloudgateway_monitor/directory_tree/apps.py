from django.apps import AppConfig


class DirectoryTreeConfig(AppConfig):
    name = 'directory_tree'
