from django.urls import include, re_path
from rest_framework import routers
from rest_framework_simplejwt import views as jwt_views
from . import views

router = routers.DefaultRouter()
router.register(r'users', views.AuthUserViewSet)
router.register(r'groups', views.AuthGroupViewSet)

# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
urlpatterns = [
    re_path('', include(router.urls)),
    re_path(r'^token/$', jwt_views.TokenObtainPairView.as_view(), name='token_obtain_pair'),
    re_path(r'^token/refresh/$', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
    re_path(r'^token/verify/$', jwt_views.TokenVerifyView.as_view(), name='token_verify'),	
]