from django.apps import AppConfig


class TokenjwtConfig(AppConfig):
    name = 'tokenjwt'
