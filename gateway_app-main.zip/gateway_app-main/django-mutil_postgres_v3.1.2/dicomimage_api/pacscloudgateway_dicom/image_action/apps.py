from django.apps import AppConfig


class ImageActionConfig(AppConfig):
    name = 'image_action'
