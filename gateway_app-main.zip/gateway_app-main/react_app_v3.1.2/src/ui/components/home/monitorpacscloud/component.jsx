import React from 'react';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarMenu,
  CDBSidebarMenuItem,} from 'cdbreact';
import { BrowserRouter, Switch, Route, NavLink } from "react-router-dom"
import{viewDrive} from './viewdrive'
import{ServiceStatus} from './servicestatus'

function MonitorPACSCloud() {
  return (
    <div className="body">

  </div>
  );
}

export {MonitorPACSCloud};