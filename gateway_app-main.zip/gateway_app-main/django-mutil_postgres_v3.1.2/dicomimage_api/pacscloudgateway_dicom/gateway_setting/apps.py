from django.apps import AppConfig


class GatewaySettingConfig(AppConfig):
    name = 'gateway_setting'
