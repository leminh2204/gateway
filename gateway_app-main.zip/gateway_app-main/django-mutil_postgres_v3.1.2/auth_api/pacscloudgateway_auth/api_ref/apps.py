from django.apps import AppConfig


class ApiRefConfig(AppConfig):
    name = 'api_ref'
