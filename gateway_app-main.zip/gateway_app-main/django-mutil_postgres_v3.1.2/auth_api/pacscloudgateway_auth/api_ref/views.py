from django.contrib.auth.models import User, Group
from user.views import UserViewSet, GroupViewSet
from .serializers import UserSerializer, GroupSerializer
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny


class AuthUserViewSet(UserViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
#   permission_classes = [permissions.IsAdminUser]
    http_method_names = ['get','post','patch','delete']
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['id', 'username', 'first_name', 'last_name', 'email']



class AuthGroupViewSet(GroupViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [IsAdminUser]
    http_method_names = ['get','post','patch','delete']